class AppImages {
  // image paths
  static const baseImagePath = "assets/images";
  static const sneaker1ImagePath = "$baseImagePath/sneaker_1.webp";
  static const labelImagePath = "$baseImagePath/label.png";
  static const kras2ImagePath = "$baseImagePath/kras2.png";
  static const kras3ImagePath = "$baseImagePath/kras3.png";
  static const kras4ImagePath = "$baseImagePath/kras4.png";
  static const kras5ImagePath = "$baseImagePath/kras5.png";
}
