import 'package:flutter/material.dart';
import 'package:sneaker_store/utils/app_colors.dart';
import 'package:sneaker_store/utils/app_images.dart';
import 'package:sneaker_store/utils/text_blue.dart';
import 'package:sneaker_store/utils/text_styles.dart';
import 'package:sneaker_store/utils/textmini_styles.dart';

class GetStartedScreen extends StatelessWidget {
  GetStartedScreen({super.key});
  final List imagePath = [
    AppImages.kras2ImagePath,
    AppImages.kras3ImagePath,
    AppImages.kras4ImagePath,
    AppImages.kras4ImagePath,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Padding(
          padding: EdgeInsets.only(left: 100),
          child: Text(
            "Sneaker Shop",
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_bag_outlined),
            onPressed: () => {}, // Implement navigation to menu screen
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const HeaderText(
              text: "Nike Air Max 270",
              textAlign: TextAlign.center,
            ),
            const HeaderText(
              text: "Essential",
              textAlign: TextAlign.center,
            ),
            const MiniText(
              text: "Men's Shoes",
              textAlign: TextAlign.center,
            ),
            const HeaderText(
              text: ('\$179.39'),
            ),
            Transform.rotate(
              angle: -0.4,
              child: SizedBox(
                width: double.infinity,
                height: 230,
                child: Image.asset(
                  AppImages.sneaker1ImagePath,
                  height: 170,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(
              width: 400,
              height: 80,
              child: Image.asset(
                AppImages.labelImagePath,
                height: 20,
                fit: BoxFit.fill,
              ),
            ),
            SizedBox(
              height: 110,
              child: ListView.builder(
                itemCount: imagePath.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (ctx, index) {
                  return Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppColors.whiteWithOpacColor,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: SizedBox(
                        width: 80,
                        height: 100,
                        child: Image.asset(
                          imagePath[index],
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const MiniText(
              text:
                  '''The Max Air 270 unit delivers unrivaled, all-day comfort. The sleek, running-inspired design roots you to everything Nike........''',
              textAlign: TextAlign.start,
            ),
            const Padding(
              padding: EdgeInsets.only(top: 10, left: 300),
              child: BluerText(
                textAlign: TextAlign.end,
                text: "Read More",
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                SizedBox(
                  height: 110,
                  child: IconButton(
                    icon: const Icon(Icons.favorite_border),
                    onPressed: () => {},
                  ),
                ),
                Container(
                  height: 70,
                  width: 250,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.shopping_bag_outlined),
                        onPressed: () => {},
                      ),
                      SizedBox(width: 10),
                      Text(
                        "Add to Cart",
                        style: TextStyle(color: AppColors.whiteWithOpacColor),
                      ),
                    ],
                  ),
                  margin: const EdgeInsets.only(left: 70),
                  decoration: BoxDecoration(
                    color: AppColors.successColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
